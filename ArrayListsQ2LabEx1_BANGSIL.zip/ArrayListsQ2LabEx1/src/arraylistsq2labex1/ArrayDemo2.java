package arraylistsq2labex1;

import java.util.ArrayList;
import java.util.Collections;

class Student2 {
    String Name;
    int Score;
    
//    <your code>

}


public class ArrayDemo2 {
    static void display(ArrayList<Student2> AS){
//        <your code to display the array elements>
        for(Student2 s : AS){
            System.out.println(s.Name + ", " + s.Score);
        }
    }

    static ArrayList<Student2> sortScores(ArrayList<Student2> AS){
       
//		<your code to sort the array>
            int HighestScore, i, j;
            int n=AS.size();
            String HighestName;

            for(i=0; i<n-1; i++){
                for(j=0;j<n-i-1;j++){
                    if(AS.get(j).Score > AS.get(j+1).Score){
                        HighestScore = AS.get(j).Score;
                        HighestName = AS.get(j).Name;
                        AS.get(j).Score = AS.get(j+1).Score;
                        AS.get(j).Name = AS.get(j+1).Name;
                        AS.get(j+1).Score = HighestScore;
                        AS.get(j+1).Name = HighestName;
                    }
                }
            }
             return AS;
    }
    static void searchHighestScore(ArrayList<Student2> AS){
//<your code to search for the highest score in the array>
            int HighestScore, i, j;
            int n=AS.size();
            String HighestName;

            for(i=0; i<n-1; i++){
                for(j=0;j<n-i-1;j++){
                    if(AS.get(j).Score > AS.get(j+1).Score){
                        HighestScore = AS.get(j).Score;
                        HighestName = AS.get(j).Name;
                        AS.get(j).Score = AS.get(j+1).Score;
                        AS.get(j).Name = AS.get(j+1).Name;
                        AS.get(j+1).Score = HighestScore;
                        AS.get(j+1).Name = HighestName;
                    }
                }
            }

            System.out.println("Highest score is: " + AS.get(n-1).Score + " from Student " + AS.get(n-1).Name);
        
    }

    static ArrayList<Student2> sortNames (ArrayList<Student2> AS){
//		<your code to sort the array according the names>  
            int HighestScore, i, j;
            int n=AS.size();
            String HighestName;

            for(i=0; i<n-1; i++){
                for(j=0;j<n-i-1;j++){
                    if(AS.get(j).Name.compareTo(AS.get(j+1).Name) > 0){
                        HighestScore = AS.get(j).Score;
                        HighestName = AS.get(j).Name;
                        AS.get(j).Score = AS.get(j+1).Score;
                        AS.get(j).Name = AS.get(j+1).Name;
                        AS.get(j+1).Score = HighestScore;
                        AS.get(j+1).Name = HighestName;
                    }
                }
            }
            
            return AS;
    }

    public static void main(String[] args) {
        ArrayList<Student2> Student2ArrayList = new ArrayList<>();

        for(int x=0; x<5; x++){Student2ArrayList.add(new Student2());}

  	 String[] NameI = {"Bok", "Mik", "Jak", "Luds", "Kim"};
        int[] ScoreI = {90, 96, 91, 97, 99};

        Student2ArrayList.get(0).Name = "Bok"; Student2ArrayList.get(0).Score = 90;
        Student2ArrayList.get(1).Name = "Mik"; Student2ArrayList.get(1).Score = 96;
        Student2ArrayList.get(2).Name = "Jak"; Student2ArrayList.get(2).Score = 91;
        Student2ArrayList.get(3).Name = "Luds"; Student2ArrayList.get(3).Score = 97;
        Student2ArrayList.get(4).Name = "Kim"; Student2ArrayList.get(4).Score = 99;

        System.out.println("Array:");
        display(Student2ArrayList);
        System.out.println();
        System.out.println("Array after sorting scores from lowest to highest:");
        display(sortScores(Student2ArrayList));
        System.out.println();
        System.out.println("Array after sorting names in alphabetical order:");
        display(sortNames(Student2ArrayList));
        System.out.println();
        searchHighestScore(Student2ArrayList);
    }
}
