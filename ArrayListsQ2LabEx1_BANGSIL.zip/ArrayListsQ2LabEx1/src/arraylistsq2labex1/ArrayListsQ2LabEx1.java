/*------------------------------------------------------------------------
CS 4 Gluon
Lab Ex 1
Class Number: 21
Name: Bangsil, Roxanne
----------------------------------------------------------------------------*/
package arraylistsq2labex1;

import java.util.ArrayList;

/**
 *
 * @author Roxanne
 */

class Student {
        String Name;
        int Score;


        public void displayArray(ArrayList<Student> AS) {
    //<your code to display the array elements>
            for(Student s : AS){
                System.out.println(s.Name + ", " + s.Score);
            }
        }

         public void searchHighestScore(ArrayList<Student> AS) {
    //<your code to search for the highest score in the array>
            int HighestScore, i, j;
            int n=AS.size();
            String HighestName;

            for(i=0; i<n-1; i++){
                for(j=0;j<n-i-1;j++){
                    if(AS.get(j).Score > AS.get(j+1).Score){
                        HighestScore = AS.get(j).Score;
                        HighestName = AS.get(j).Name;
                        AS.get(j).Score = AS.get(j+1).Score;
                        AS.get(j).Name = AS.get(j+1).Name;
                        AS.get(j+1).Score = HighestScore;
                        AS.get(j+1).Name = HighestName;
                    }
                }
            }

            System.out.println("Highest score is: " + AS.get(n-1).Score + " from Student " + AS.get(n-1).Name);
        }    
        public void sortScores(ArrayList<Student> AS) {
    //        	<your code to sort the array>  sorting from lowest to highest
            int HighestScore, i, j;
            int n=AS.size();
            String HighestName;

            for(i=0; i<n-1; i++){
                for(j=0;j<n-i-1;j++){
                    if(AS.get(j).Score > AS.get(j+1).Score){
                        HighestScore = AS.get(j).Score;
                        HighestName = AS.get(j).Name;
                        AS.get(j).Score = AS.get(j+1).Score;
                        AS.get(j).Name = AS.get(j+1).Name;
                        AS.get(j+1).Score = HighestScore;
                        AS.get(j+1).Name = HighestName;
                    }
                }
            }
        }

        public void sortNames(ArrayList<Student> AS) {
    //<your code to sort the array according the names> Alphabetical order A-Z
            int HighestScore, i, j;
            int n=AS.size();
            String HighestName;

            for(i=0; i<n-1; i++){
                for(j=0;j<n-i-1;j++){
                    if(AS.get(j).Name.compareTo(AS.get(j+1).Name) > 0){
                        HighestScore = AS.get(j).Score;
                        HighestName = AS.get(j).Name;
                        AS.get(j).Score = AS.get(j+1).Score;
                        AS.get(j).Name = AS.get(j+1).Name;
                        AS.get(j+1).Score = HighestScore;
                        AS.get(j+1).Name = HighestName;
                    }
                }
            }
       }

    }

public class ArrayListsQ2LabEx1 {

    /**
     * @param args the command line arguments
     */

        public static void main(String[] args) {
            String[] NameI = {"Bok", "Mik", "Jak", "Luds", "Kim"};
            int[] ScoreI = {90, 96, 91, 97, 99};

            ArrayList<Student> StudentArrayList = new ArrayList<Student>();
            for (int i = 0; i <= 4; i++) {
                StudentArrayList.add(new Student());
                StudentArrayList.get(i).Name = NameI[i];
                StudentArrayList.get(i).Score = ScoreI[i];
            }


            Student method = new Student();

            System.out.println("Array:");
            method.displayArray(StudentArrayList);
            
            System.out.println();
            
            method.searchHighestScore(StudentArrayList);

            method.sortScores(StudentArrayList);

            System.out.println();
            System.out.println("Array after sorting scores from lowest to highest:");
            
            method.displayArray(StudentArrayList);

            method.sortNames(StudentArrayList);

            System.out.println();
            System.out.println("Array after sorting names in alphabetical order:");
            
            method.displayArray(StudentArrayList);        


        }
    }



