package arraylistsq2labex1;
import java.util.*;

class Student3 {
    String Name;
    int Score;
    
    
    public void displayArray(ArrayList<Student3> AS) {
//<your code to display the array elements>
        for(Student3 s : AS){
            System.out.println(s.Name + ", " + s.Score);
        }
    }
    
     public void searchHighestScore(ArrayList<Student3> AS) {
//<your code to search for the highest score in the array>
        int HighestScore, i, j;
        int n=AS.size();
        String HighestName = AS.get(0).Name;
        
        HighestScore = AS.get(0).Score;
        
        for(i=0; i<n-1; i++){
            for(j=0;j<n-i-1;j++){
                if(AS.get(j).Score > AS.get(j+1).Score){
                    HighestScore = AS.get(j).Score;
                    HighestName = AS.get(j).Name;
                    AS.get(j).Score = AS.get(j+1).Score;
                    AS.get(j).Name = AS.get(j+1).Name;
                    AS.get(j+1).Score = HighestScore;
                    AS.get(j+1).Name = HighestName;
                }
            }
        }
        
        System.out.println("Highest score is: " + HighestScore + "from Student " + HighestName);
    }    
    public void sortScores(ArrayList<Student3> AS) {
//        	<your code to sort the array>  sorting from lowest to highest
        int HighestScore, i, j;
        int n=AS.size();
        String HighestName;
        
        HighestScore = AS.get(0).Score;
        
        for(i=0; i<n-1; i++){
            for(j=0;j<n-i-1;j++){
                if(AS.get(j).Score > AS.get(j+1).Score){
                    HighestScore = AS.get(j).Score;
                    HighestName = AS.get(j).Name;
                    AS.get(j).Score = AS.get(j+1).Score;
                    AS.get(j).Name = AS.get(j+1).Name;
                    AS.get(j+1).Score = HighestScore;
                    AS.get(j+1).Name = HighestName;
                }
            }
        }
    }
    
    public void sortNames(ArrayList<Student3> AS) {
//<your code to sort the array according the names> Alphabetical order A-Z
        int HighestScore, i, j;
        int n=AS.size();
        String HighestName;
        
        HighestScore = AS.get(0).Score;
        
        for(i=0; i<n-1; i++){
            for(j=0;j<n-i-1;j++){
                if(AS.get(j).Name.compareTo(AS.get(j+1).Name) > 0){
                    HighestScore = AS.get(j).Score;
                    HighestName = AS.get(j).Name;
                    AS.get(j).Score = AS.get(j+1).Score;
                    AS.get(j).Name = AS.get(j+1).Name;
                    AS.get(j+1).Score = HighestScore;
                    AS.get(j+1).Name = HighestName;
                }
            }
        }
   }

}

public class ArrayDemo1 {
    public static void main(String[] args) {
        String[] NameI = {"Bok", "Mik", "Jak", "Luds", "Kim"};
        int[] ScoreI = {90, 96, 91, 97, 99};
        
        ArrayList<Student3> StudentArrayList = new ArrayList<Student3>();
        for (int i = 0; i <= 4; i++) {
            StudentArrayList.add(new Student3());
            StudentArrayList.get(i).Name = NameI[i];
            StudentArrayList.get(i).Score = ScoreI[i];
        }
        
       
        Student3 method = new Student3();

        method.displayArray(StudentArrayList);

        method.searchHighestScore(StudentArrayList);

        method.sortScores(StudentArrayList);
        
        method.displayArray(StudentArrayList);

        method.sortNames(StudentArrayList);
        
        method.displayArray(StudentArrayList);        
        
   
    }
}

